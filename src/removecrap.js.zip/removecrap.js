channels = ['NASASpaceflight',
'PickFingerstyle',
'relaxdaily',
'3Blue1Brown',
'10 Percent True - Tales from the Cockpit',
'A.I.Channel',
'A.I.Games',
'AI บ้านบ้าน',
'Airspace',
'Arxiv Insights',
'AVIATION E-SPORT',
'Beyond the press',
'blackpenredpen',
'C.W. Lemoine',
'Casual Navigation',
'Citra Emulator',
'Code Bullet',
'DeepMind',
'dota2',
'Drachinifel',
'Eagle Dynamics: Digital Combat Simulator',
'Engineering Explained',
'Forgotten Weapons',
'Geographics',
'GlowingAmraam',
'Growling Sidewinder',
'guitargt fingerstyle',
'Heatblur Simulations',
'Helpful Vancouver Vet',
'HokiHoshi',
'HUMANKIND',
'Imperial Knowledge',
'InRangeTV',
'J.O.E. VGM',
'Jim Browning',
'JunsKitchen',
'Karol Majek',
'Lady of Scrolls',
'LeiosOS',
'Lex',
'Mark Rober',
'Mathologer',
'Matt Wagner',
'Megaprojects',
'Microsoft Flight Simulator',
'mid or meepo',
'Military History in a Minute',
'Military History Visualized',
'MindYourDecisions',
'MIT OpenCourseWare',
'Nintendo',
'nipanartofmedia',
'Nobu Matsumura',
"Nutsinee's Vlog Book",
'OpenAI',
'Physics Explained',
'Practical Engineering',
'RAZBAM Simulations Official Channel',
'Real Engineering',
'Real Science',
'Rebelzize',
'Reducible',
'RekiFr',
'Smarter Every Day 2',
'SmarterEveryDay',
'SpaceX',
'Squash Clay',
'Tactical Pascale',
'TESRSkywindOfficial',
'The Efficient Engineer',
'The Official Pokémon YouTube channel',
'The Ready Room',
'The Soul of Wind',
'Think Twice',
'Two Minute Papers',
'VASAviation -',
'Welch Labs',
'Yannic Kilcher',
'yovo68',
'SQUARE ENIX'];

window.setInterval(removecraps, 200);

// todo: add 6 months and minutes instead
// todo: add up next
var classname = "ytd-rich-item-renderer";
var mobile = false;
if (navigator.userAgent.toLowerCase().includes("android")){
    classname = "ytm-rich-item-renderer";
    mobile = true;
}


function removecrapupnext(mobile){
    if (!mobile){
        grids = document.getElementsByTagName("ytd-compact-video-renderer")
    }
}

function removecrap(date, channel, grid){
    if (!channels.includes(channel)){
        if (date.includes("minute") || date.includes("hour") || date.includes("day") || date.includes("week") || date.includes("month")){
            grid.remove();
            i -= 1;
            
        }
    }
}

function removedesktopcrap(grid, grid_inner){
    channel = grid_inner[grid_inner.length - 3];
    if (grid_inner[grid_inner.length - 1].toLowerCase() === 'live now'){
        date = "12 hours ago";
    }
    else if (grid_inner[0] === "LIVE"){
        date = "12 hours ago";
    }
    else{
        date = grid_inner[grid_inner.length - 1];
    }
    removecrap(date, channel, grid);
}

function removemobilecrap(grid, grid_inner){
    grid_inner_info = grid_inner[grid_inner.length - 1].split("•")
    if (grid_inner[0] === "LIVE"){
        date = "12 hours ago";
        channel = grid_inner_info[0];
    }
    else {
        date = grid_inner_info[grid_inner_info.length - 1];
        channel = grid_inner_info[0];
    }
    removecrap(date, channel, grid);
}

function removecraps(){
    grids = document.getElementsByTagName(classname)
    for (var i = 0; i < grids.length; i++) { 
        if (i >= grids.length){
            break;
        }
        grid = grids[i];
        grid_inner = grid.innerText.split('\n');
        if (grid_inner[grid_inner.length - 1]==="New"){
            grid_inner.splice(grid_inner.length-1)
        }
        if (!mobile){
            removedesktopcrap(grid, grid_inner);
        }
        else{
            removemobilecrap(grid, grid_inner);
        }        
    }
    if (!mobile){
        grids = document.getElementsByTagName("ytd-compact-video-renderer");
        for (var i = 0; i < grids.length; i++) { 
            if (i >= grids.length){
                break;
            }
            grid = grids[i];
            grid_inner = grid.innerText.split('\n');
            if (grid_inner[grid_inner.length - 1]==="New"){
                grid_inner.splice(grid_inner.length-1)
            }
            removedesktopcrap(grid, grid_inner);
        }
    }
}